package com.flixmc.materialpack;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class MaterialPackScreen extends Screen {
    private static final int PANEL_WIDTH = 430;
    private static final int ROW_HEIGHT = 22;
    private List<Row> rows = List.of();
    private String schematicName = "";
    private String status = "";
    private int scroll;

    public MaterialPackScreen() {
        super(Component.literal("Material Pack"));
        reloadMaterials();
    }

    @Override
    protected void init() {
        super.init();
        addRenderableWidget(net.minecraft.client.gui.components.Button.builder(
                Component.literal("Atualizar"), button -> reloadMaterials())
                .bounds(width / 2 + PANEL_WIDTH / 2 - 94, height / 2 - 126, 84, 20).build());
        addRenderableWidget(net.minecraft.client.gui.components.Button.builder(
                Component.literal("Fechar"), button -> onClose())
                .bounds(width / 2 + PANEL_WIDTH / 2 - 94, height / 2 + 132, 84, 20).build());
    }

    private void reloadMaterials() {
        List<Row> found = new ArrayList<>();
        schematicName = "";
        status = "";
        try {
            Class<?> dataManager = Class.forName("fi.dy.masa.litematica.data.DataManager");
            Object manager = dataManager.getMethod("getSchematicPlacementManager").invoke(null);
            Object placement = manager.getClass().getMethod("getSelectedSchematicPlacement").invoke(manager);
            if (placement == null) {
                status = "Nenhuma schematic selecionada no Litematica.";
                rows = List.of();
                return;
            }

            Object name = placement.getClass().getMethod("getName").invoke(placement);
            schematicName = String.valueOf(name);
            Object materialList = placement.getClass().getMethod("getMaterialList").invoke(placement);
            Object materialEntries = materialList.getClass().getMethod("getAllMaterials").invoke(materialList);
            if (materialEntries instanceof Iterable<?> entries) {
                for (Object entry : entries) {
                    ItemStack stack = (ItemStack) entry.getClass().getMethod("getStack").invoke(entry);
                    long total = ((Number) entry.getClass().getMethod("getCountTotal").invoke(entry)).longValue();
                    if (stack == null || stack.isEmpty() || total <= 0) continue;
                    int maxStack = Math.max(1, stack.getMaxStackSize());
                    long stackCount = total / maxStack;
                    long remainder = total % maxStack;
                    String amount = stackCount + " stacks" + (remainder > 0 ? " + " + remainder : "");
                    if (stackCount == 0) amount = Long.toString(total);
                    found.add(new Row(stack.copy(), total, amount));
                }
            }
            found.sort(Comparator.comparingLong(Row::total).reversed());
            rows = List.copyOf(found);
            status = rows.isEmpty() ? "A lista retornou vazia. Tente Atualizar." : rows.size() + " tipos de materiais";
            scroll = 0;
        } catch (ClassNotFoundException e) {
            rows = List.of();
            status = "Litematica não encontrada. Instale Litematica + MaLiLib.";
        } catch (ReflectiveOperationException | RuntimeException e) {
            rows = List.of();
            status = "Não consegui ler a schematic. Confira a versão do Litematica.";
        }
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        renderBackground(graphics, mouseX, mouseY, delta);
        int left = (width - PANEL_WIDTH) / 2;
        int top = (height - 270) / 2;
        graphics.fill(left, top, left + PANEL_WIDTH, top + 270, 0xE9101218);
        graphics.renderOutline(left, top, PANEL_WIDTH, 270, 0xFF555D70);
        graphics.drawCenteredString(font, "Material Pack", width / 2, top + 10, 0xFFFFFFFF);
        graphics.drawString(font, schematicName.isBlank() ? "Schematic ativa" : schematicName,
                left + 12, top + 31, 0xFFB7C7E8, false);
        graphics.drawString(font, "Item", left + 12, top + 52, 0xFFFFFFFF, false);
        graphics.drawString(font, "Quantidade compacta", left + 235, top + 52, 0xFFFFFFFF, false);

        int visibleRows = 8;
        for (int i = scroll; i < Math.min(rows.size(), scroll + visibleRows); i++) {
            Row row = rows.get(i);
            int y = top + 70 + (i - scroll) * ROW_HEIGHT;
            if ((i - scroll) % 2 == 0) graphics.fill(left + 8, y - 3, left + PANEL_WIDTH - 8, y + 17, 0x553B4250);
            graphics.renderItem(row.stack(), left + 12, y - 2);
            graphics.drawString(font, trim(row.stack().getHoverName().getString(), 29), left + 34, y + 2, 0xFFEAEAEA, false);
            graphics.drawString(font, row.amount(), left + 235, y + 2, 0xFF8FE3A0, false);
        }
        graphics.drawString(font, status, left + 12, top + 252, 0xFFB8B8B8, false);
        super.render(graphics, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int maxScroll = Math.max(0, rows.size() - 8);
        scroll = (int) Math.max(0, Math.min(maxScroll, scroll - Math.signum(verticalAmount) * 3));
        return true;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private static String trim(String text, int max) {
        return text.length() <= max ? text : text.substring(0, Math.max(0, max - 3)) + "...";
    }

    private record Row(ItemStack stack, long total, String amount) { }
}
